import { Component } from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';
import { TranslateService } from 'ng2-translate/ng2-translate';


@Component({
  selector: 'app-root',
  template: `
  <div class="">
    <router-outlet></router-outlet>
    </div>
  `
})

export class AppComponent {


  constructor(){}
}