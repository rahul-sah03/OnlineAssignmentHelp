import { NgModule } from '@angular/core';
import { RouterModule, Routes, Router, CanLoad } from '@angular/router';


const ROUTES: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(ROUTES)],
  exports: [RouterModule]
})

export class AppControllerModule {}